package com.s25.Hibernates25SQL;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App 
{
    public static void main( String[] args )
    {
     try
     {
    Configuration con=new Configuration();
    	con.configure(); 
    	
    	SessionFactory sf=con.buildSessionFactory();
    	Session s=sf.openSession();
    	
    	Transaction t=s.beginTransaction();
    	
    	Employee ob1=new Employee();
    	ob1.setEno(101);
    	ob1.setEname("SHIVA");
    	ob1.setEsal(100000);
    	ob1.setEnum1(995987300);
    	ob1.setEplace("WGL");
    	
    	s.save(ob1);
    	
    	Employee ob2=new Employee();
    	ob2.setEname("KAMAL");
    	ob2.setEno(102);
    	ob2.setEsal(200000);
    	ob2.setEnum1(628106533);
    	ob2.setEplace("HNK");
    	 
    	s.save(ob2);
    	
    	Employee ob3=new Employee();
    	ob3.setEname("MSK");
    	ob3.setEno(103);
    	ob3.setEsal(300000);
    	ob3.setEnum1(949153313);
    	ob3.setEplace("ETURNAGARAM");
    	 
    	s.save(ob3);
    	t.commit();
    	
    	
     }
     catch(Exception e)
     {
    	 
     }
     
     
     
}  
}


