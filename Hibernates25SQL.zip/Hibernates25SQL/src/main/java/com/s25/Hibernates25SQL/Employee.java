package com.s25.Hibernates25SQL;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class Employee {
	@Id
	int eno;
	String ename;
	int esal;
	int enum1;
	String eplace;
	public int getEno() {
		return eno;
	}
	public void setEno(int eno) {
		this.eno = eno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public int getEsal() {
		return esal;
	}
	public void setEsal(int esal) {
		this.esal = esal;
	}
	public int getEnum1() {
		return enum1;
	}
	public void setEnum1(int enum1) {
		this.enum1 = enum1;
	}
	public String getplace() {
		return eplace;
	}
	public void setEplace(String eplace) {
		this.eplace = eplace;
	}
	@Override
	public String toString() {
		return "Employee [eno=" + eno + ", ename=" + ename + ", esal=" + esal + ", enum1=" + enum1 + " eplace=" + eplace + ",]";
	}
	
	

}
